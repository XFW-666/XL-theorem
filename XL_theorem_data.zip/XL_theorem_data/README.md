# XL theorem — verification code and data

Computational material for the manuscript

> **The XL theorem: rank-one structure of coupled concatenation arithmetic
> progressions, digit-sum slices and the distribution of perfect powers**

The package contains the programs that verify every computational assertion of
the paper, the programs that draw the six figures, and the numerical data behind
them.  It is self-contained: no external data files are required, and every
quantity is recomputed from its definition.

## Layout

```
verify/     verification programs, one per group of results
figures/    figure-drawing programs
data/       numerical data written by `verify/run_all.py`
outputs/    console logs written by `verify/run_all.py`
```

## Requirements

Python 3.9 or later with

```
numpy
matplotlib
mpmath
sympy
```

Install with `pip install -r requirements.txt`.

## Running

```
python verify/run_all.py
```

This runs every verification program, prints a pass/fail line for each check,
writes the numerical tables into `data/`, the logs into `outputs/`, and finally
regenerates the six figures into `data/figures/`.  The whole run takes a few
minutes on an ordinary laptop.

Individual programs can also be run on their own, for example

```
python verify/verify_sections_2_4.py
python verify/compute_constants.py
python figures/make_figures.py
```

## What each program verifies

| Program | Results checked |
|---|---|
| `verify/verify_sections_2_4.py` | Theorem 2.1 (rank-one kernel, modular invariants), Theorem 3.1 (structure and cardinality of $D_B$), Theorem 3.2 (membership test and closed-form indicator), Theorem 4.1 (staircase and jumps), Theorem 4.2 (iterated tower), Theorem 4.3 (transfer differences and the lattice they generate), Theorem 4.4 (slice counts, Dirichlet symmetry, greedy extrema) |
| `verify/verify_section_5.py` | Theorem 5.1 (vanishing criterion), Theorem 5.2 (digit-moment closed form), Proposition 5.3 (the discrete constant $\Delta_B$ and its separation from $C_B$), Theorem 5.5 (exponential bracket), Theorem 5.6 (Fourier identity and the remainder bound), Theorem 5.7 (failure of the sup-norm hypothesis), Theorem 5.9 (carry identity), Conjecture 5.10 (pair-correlation ratio) |
| `verify/verify_sections_6_7.py` | Theorem 6.1 (positive-segment double squares), Theorem 6.2 (Pell orbits), Theorem 7.1 (reverse characterization), Theorem 7.2 (finite fields and modular rings) |
| `verify/verify_appendix.py` | Theorem A.1 (checksum blind spot), Theorem A.3 (the minimal counterexample in base three), Theorem A.4 (decidability) |
| `verify/compute_constants.py` | The constants $C_B$ (to 200 working digits) and $\Delta_B$ (by extrapolation), and the rate at which the closed form of Theorem 5.2 converges |
| `figures/make_figures.py` | Regenerates Figures 1–6 |

## Data files

| File | Contents |
|---|---|
| `data/C_B_and_Delta_B.csv` | the two constants for $B=2,3,5,7,10,16$, their difference, and the convergence ratios of $F_j$ |
| `data/closed_form_error.csv` | the error $\left|\sum_{j\le r}F_j-\left(\frac{B-1}{2}r+C_B\right)\right|$ |
| `data/L1_errors.csv` | the $L_1$ error of the density-corrected main term and of the uniform model over $|n-\mu_r|\le 3\sigma_r$ |
| `data/exponential_bracket.csv` | $\max_n N_{B,r}(n)$ against the bracket of Theorem 5.5 |
| `data/supnorm_quotients.csv` | $M/X$ at the thresholds $\delta=X^{-1/2}$ and $\delta=X^{-1}$ |
| `data/carry_counts.csv` | $E[\kappa]/r$ for the bases and digit counts quoted in the paper |
| `data/pair_correlation.csv` | the ratio of Conjecture 5.10 for five bases |
| `data/pell_orbits.csv` | the orbits of $y^2-Bx^2=c$ and the line $T=10S+1$ |
| `data/checksum_detection.csv` | detection rates of the two classical moduli |
| `data/figures/F1.png` … `F6.png` | the six figures |

## Conventions

Throughout, $\sigma_B(v)$ is the sum of the base-$B$ digits of $v$,
$N_{B,r}(n)=\#\{x\ge0: x^2<B^r,\ \sigma_B(x^2)=n\}$,
$X=\lceil B^{r/2}\rceil$ is the number of admissible $x$,
$\lambda_B(n)$ is the number of square roots of $n$ modulo $B-1$, and
$C_{B,r}(n)$ is the number of $r$-tuples of digits with sum $n$.
The discrete mean is $\mu_r=\frac1X\sum_n n\,N_{B,r}(n)$ and
$\Delta_B=\lim_{r\to\infty}\big(\mu_r-\frac{B-1}{2}r\big)$.

## Licence

Released under the MIT Licence; see `LICENSE`.

## Citing

If you use this code or data, please cite the manuscript.  A machine-readable
record is provided in `CITATION.cff`.
