# -*- coding: utf-8 -*-
"""Rebuild all six figures with an automatic overlap check.

Every figure is refused unless the checker reports no text/text and no
text/data overlap.  The generators are the ones shipped with the data package.
"""
import math
import os
import os
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import figkit as K  # noqa: E402
from figkit import C1, C2, C3, WB  # noqa: E402

C_ORANGE = '#e08214'
C_PURPLE = '#7b52ab'
C_GREY = '0.6'

PROBLEMS = {}


# ==================================================================== F1
def fig1(path=None):
    path = path or _p('F1')
    B = 10
    fig, ax = plt.subplots(figsize=(6.6, 2.6))
    ax.axhline(0, color='0.82', lw=2.4, zorder=1)
    for a in range(B - 1):
        lo, hi = B * a, (a + 1) * (B - 1)
        ax.add_patch(plt.Rectangle((lo, -0.30), hi - lo, 0.60,
                                   facecolor=C1, edgecolor='none', zorder=2))
    for v in (3, 12, 21, 30):
        ax.plot([v], [0], 'o', ms=5.2, mfc=C2, mec='k', mew=0.5, zorder=4)
    for v in (39, 48):
        ax.plot([v], [0], 'X', ms=6.4, mfc='none', mec=C2, mew=1.1, zorder=4)
    ax.annotate('$n=3$: the four values in $D_{10}$', xy=(9.4, 0.34),
                xytext=(13.5, 1.62), ha='center', va='bottom', fontsize=7.6,
                arrowprops=dict(arrowstyle='-', lw=0.6, color='0.35'))
    ax.annotate('$a=4,5$: super segment\n$39,\\ 48\\notin D_{10}$',
                xy=(43.6, 0.36), xytext=(57.0, 1.20), ha='center', va='bottom',
                fontsize=7.6,
                arrowprops=dict(arrowstyle='-', lw=0.6, color='0.35'))
    ax.set_xlim(-4, 86)
    ax.set_ylim(-1.30, 2.55)
    ax.set_xlabel('$u$', labelpad=2)
    ax.set_yticks([])
    for s in ('left', 'right', 'top'):
        ax.spines[s].set_visible(False)
    ax.spines['bottom'].set_position(('data', -1.05))
    ax.set_xticks([0, 20, 40, 60, 80])
    return K.save(fig, 'Figure 1', path)


# ==================================================================== F2
def fig2(path=None):
    path = path or _p('F2')
    B = 10
    fig = plt.figure(figsize=(6.8, 3.6))
    gs = fig.add_gridspec(2, 2, hspace=0.52, wspace=0.30)

    ax = fig.add_subplot(gs[0, 0])
    for r, st in ((2, '-'), (4, '--'), (6, '-.'), (8, ':')):
        ns = list(range(0, r * (B - 1) + 1))
        ax.semilogy(ns, [max(K.slice_count(B, r, n), 0.5) for n in ns],
                    st, lw=1.0, color=C1, label='$r=%d$' % r)
    ax.set_xlabel('digit sum $n$', labelpad=1)
    ax.set_ylabel('$C_{10,r}(n)$', labelpad=1)
    ax.set_title('(a) slice counts', pad=3)
    ax.set_ylim(0.4, 3.0e11)         # free band 10^8..10^11
    ax.legend(frameon=False, ncol=1, loc='upper left')

    ax = fig.add_subplot(gs[0, 1])
    ns = list(range(0, 55))
    ax.plot(ns, [K.slice_count(B, 6, n) for n in ns], '-', lw=1.0, color=C1,
            label='$C_{10,6}(n)$')
    ax.plot(ns, [K.slice_count(B, 6, 54 - n) for n in ns], '--', lw=1.0,
            color=C2, label='$C_{10,6}(54-n)$')
    ax.set_xlim(-2.5, 56.5)
    ax.set_ylim(-2600, 82000)        # margin + free upper-left corner
    ax.set_xlabel('$n$', labelpad=1)
    ax.set_ylabel('count', labelpad=1)
    ax.set_title('(b) Dirichlet symmetry', pad=3)
    ax.legend(frameon=False, ncol=1, loc='upper left')

    ax = fig.add_subplot(gs[1, 0])
    r = 4
    for n in range(0, r * (B - 1) + 1):
        v = K.slice_values(B, r, n)
        if v:
            ax.plot([n, n], [min(v), max(v)], '-', lw=1.1, color='0.85', zorder=1)
    ax.plot(range(0, r * (B - 1) + 1),
            [max(K.slice_values(B, r, n)) for n in range(0, r * (B - 1) + 1)],
            'o', ms=2.6, color=C3, zorder=3, label='greedy max')
    ax.plot(range(0, r * (B - 1) + 1),
            [min(K.slice_values(B, r, n)) for n in range(0, r * (B - 1) + 1)],
            'o', ms=2.6, color=C2, zorder=3, label='greedy min')
    ax.set_xlabel('digit sum $n$', labelpad=1)
    ax.set_ylabel('$V_B$', labelpad=1)
    ax.set_title('(c) slice values and greedy extrema', pad=3)

    ax = fig.add_subplot(gs[1, 1])
    bases = [3, 5, 10, 16]
    cols = (C1, C2, C3)
    labs = ('$B-1$', '$2(B-1)$', '$B^2-1$')
    x = np.arange(len(bases))
    w = 0.24
    for i in range(3):
        vals = [[b - 1, 2 * (b - 1), b * b - 1][i] for b in bases]
        ax.bar(x + (i - 1) * w, vals, width=w, color=cols[i], label=labs[i])
    ax.set_yscale('log')
    ax.set_xticks(x)
    ax.set_xticklabels(['$B=%d$' % b for b in bases])
    ax.set_ylabel('difference', labelpad=1)
    ax.set_title('(d) transfer differences', pad=3)
    return K.save(fig, 'Figure 2', path)


# ==================================================================== F3
def fig3(path=None):
    path = path or _p('F3')
    B = 10
    fig = plt.figure(figsize=(7.0, 2.8))
    gs = fig.add_gridspec(1, 3, wspace=0.36)

    ax = fig.add_subplot(gs[0, 0])
    r = 8
    sig = K.Sig(B)
    cnt, mu, sd, X = K.counts(B, r, sig)
    ns = sorted(cnt)
    ax.bar(ns, [cnt[n] for n in ns], width=0.9, color=C1, zorder=2)
    S = {n: 0.0 for n in ns}

    def rec(i, left, val, n):
        if i == r:
            if left == 0 and val > 0:
                S[n] += 0.5 / math.sqrt(val)
            return
        for d in range(0, min(B - 1, left) + 1):
            rec(i + 1, left - d, val + d * (B ** (r - 1 - i)), n)
    for n in ns:
        rec(0, n, 0, n)
    ax.plot(ns, [K.lam_b(n, B) * S[n] for n in ns], '-', lw=1.1, color=C2,
            zorder=3, label='main term')
    ax.set_xlabel('digit sum $n$', labelpad=1)
    ax.set_ylabel('count', labelpad=1)
    ax.set_title('(a) counts vs main term', pad=3)

    ax = fig.add_subplot(gs[0, 1])
    r = 6
    cnt, mu, sd, X = K.counts(B, r, sig)
    sg = [sig(x * x) for x in range(X)]
    ths = [t / 2000.0 for t in range(0, 1001)]
    vals = []
    for th in ths:
        re_ = math.fsum(math.cos(2 * math.pi * th * v) for v in sg)
        im_ = math.fsum(math.sin(2 * math.pi * th * v) for v in sg)
        vals.append(math.hypot(re_, im_) / X)
    ax.plot(ths, vals, '-', lw=1.0, color=C1)
    for j in range(1, 5):
        ax.axvline(j / (B - 1), ls=':', lw=0.7, color='0.55')
    ax.annotate('$1/3$: $0.577$', xy=(1 / 3.0, 0.577), xytext=(0.30, 0.72),
                fontsize=6.6, ha='center', va='bottom', bbox=WB,
                arrowprops=dict(arrowstyle='->', lw=0.6, color='0.35'))
    ax.set_ylim(-0.045, 1.075)
    ax.set_xlabel('$\\theta$', labelpad=1)
    ax.set_ylabel('$|F_r(\\theta)|/X$', labelpad=1)
    ax.set_title('(b) spike and resonances', pad=3)

    ax = fig.add_subplot(gs[0, 2])
    for B2, col in ((2, C_PURPLE), (3, C2), (5, C3), (7, C_ORANGE), (10, C1)):
        sig2 = K.Sig(B2)
        rs, R = [], []
        for r2 in range(4, 22):
            X2 = int(math.ceil(B2 ** (r2 / 2.0)))
            if X2 > 400000:
                break
            c2, m2, s2, _ = K.counts(B2, r2, sig2)
            lhs = sum(v * v for v in c2.values())
            rhs = X2 * X2 * sum(
                K.lam_b(n, B2) ** 2
                * (math.exp(-((n - m2) ** 2) / (s2 * s2))
                   / (2 * math.pi * s2 * s2)) for n in c2)
            rs.append(r2)
            R.append(lhs / rhs)
        ax.plot(rs, R, 'o-', ms=2.0, lw=0.8, color=col, label='$B=%d$' % B2)
    ax.axhline(1.0, ls='--', lw=0.8, color='0.55')
    ax.set_ylim(0.86, 2.55)          # free band 2.0..2.55
    ax.set_xlabel('$r$', labelpad=1)
    ax.set_ylabel('$R$', labelpad=1)
    ax.set_title('(c) pair correlation', pad=3)
    ax.legend(frameon=False, ncol=1, loc='upper left')
    return K.save(fig, 'Figure 3', path)


# ==================================================================== F3v
def fig3v(path=None):
    path = path or _p('F3v')
    from collections import defaultdict
    fig = plt.figure(figsize=(6.8, 3.5))
    gs = fig.add_gridspec(2, 2, hspace=0.52, wspace=0.30)

    ax = fig.add_subplot(gs[0, 0])
    B, r = 10, 8
    cnt = defaultdict(int)
    k = 0
    while k * k < B ** r:
        cnt[K.Sig(B)(k * k)] += 1
        k += 1
    m = B - 1
    qr = {n % m for n in cnt}
    ks = sorted(cnt)
    ax.bar(ks, [cnt[n] for n in ks], width=1.0,
           color=[C1 if n % m in qr else C2 for n in ks])
    for n in range(0, r * m + 1):
        if n % m not in qr:
            ax.plot([n], [14], marker='v', ms=1.8, color=C2)
    ax.set_xlabel('digit sum $n$', labelpad=1)
    ax.set_ylabel('$N_{10,8}(n)$', labelpad=1)
    ax.set_title('(a) hits and forbidden classes', pad=3)

    ax = fig.add_subplot(gs[0, 1])
    Bs = [3, 5, 7, 10, 16]
    for i, B2 in enumerate(Bs):
        mm = B2 - 1
        for c in range(mm):
            ok = any((t * t - c) % mm == 0 for t in range(mm))
            ax.add_patch(plt.Rectangle((c - 0.42, i - 0.32), 0.84, 0.64,
                                       color=C1 if ok else '0.90'))
    ax.set_xlim(-0.8, 15.4)
    ax.set_ylim(-0.55, len(Bs) - 0.45)
    ax.set_yticks(range(len(Bs)))
    ax.set_yticklabels(['$B=%d$' % b for b in Bs])
    ax.set_xlabel('$n$ mod $(B-1)$', labelpad=1)
    ax.set_title('(b) admissible classes', pad=3)

    ax = fig.add_subplot(gs[1, 0])
    B, r = 3, 12
    cnt = defaultdict(int)
    k = 0
    while k * k < B ** r:
        cnt[K.Sig(B)(k * k)] += 1
        k += 1
    vals = [cnt.get(n, 0) for n in range(0, r * (B - 1) + 1)]
    ax.bar(range(0, r * (B - 1) + 1), vals, width=0.85, color=C1)
    top = max(vals)
    ax.axvline(3, color=C2, lw=0.9, zorder=3)
    ax.text(3, top * 1.05, '$n=3$ impossible', ha='center', va='bottom',
            fontsize=6.4, color=C2, bbox=WB, zorder=5)
    ax.set_ylim(0, top * 1.20)
    ax.set_xlabel('digit sum $n$', labelpad=1)
    ax.set_ylabel('$N_{3,12}(n)$', labelpad=1)
    ax.set_title('(c) $B=3$: not sufficient', pad=3)

    ax = fig.add_subplot(gs[1, 1])
    B, n = 10, 57
    A = list(range(0, 58))
    v = [K.sig_val(a, B, n) for a in A]
    ax.plot(A, v, '-', lw=1.1, color=C1, zorder=3)
    ax.plot([48], [v[48]], 'o', ms=4.0, mfc=C2, mec='k', mew=0.4, zorder=5)
    LEAD = dict(arrowstyle='-', lw=0.55, color='0.45', shrinkA=1.5, shrinkB=1.5)
    ax.annotate('slope $B^2-1$', xy=(22, v[22]), xytext=(19, v[22] + 1450),
                fontsize=6.4, color='0.15', bbox=WB, ha='center', va='bottom',
                arrowprops=LEAD, zorder=6)
    ax.annotate('slope $B-1$', xy=(53, v[53]), xytext=(54.5, v[53] + 620),
                fontsize=6.4, color='0.15', bbox=WB, ha='center', va='bottom',
                arrowprops=LEAD, zorder=6)
    ax.annotate('drop $-4221$', xy=(47.3, (v[47] + v[48]) / 2),
                xytext=(38.0, v[47] * 0.45), fontsize=6.2, color='0.15', bbox=WB,
                ha='center', va='center', arrowprops=LEAD, zorder=6)
    ax.plot([47], [v[47]], 'o', ms=3.0, mfc='white', mec=C1, mew=0.9, zorder=5)
    ax.set_ylim(-320, 5900)
    ax.set_xlabel('$a$', labelpad=1)
    ax.set_ylabel('$\\Gamma_B(a,57-a)$', labelpad=1)
    ax.set_title('(d) exact concatenation', pad=3)
    return K.save(fig, 'Figure 3 (vanishing)', path)


# ==================================================================== F5
def fig5(path=None):
    path = path or _p('F5')
    C_TRUE = {2: -0.793618, 3: -1.026326, 5: -1.464413,
              7: -1.882907, 10: -2.490281, 16: -3.664427}
    DELTA = {2: -2.2916, 3: -2.0418, 5: -1.9844,
             7: -3.5659, 10: -3.8740, 16: -9.1604}
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                    '..', 'verify'))
    from xl_common import F_j as Fj

    fig = plt.figure(figsize=(6.7, 3.2))
    gs = fig.add_gridspec(2, 2, hspace=0.50, wspace=0.32)

    ax = fig.add_subplot(gs[0, 0])
    for B in (3, 5, 7, 10):
        js, fs = [], []
        for j in range(1, 10):
            if B ** (j - 1) > 2e6:
                break
            js.append(j)
            fs.append(float(Fj(B, j)))
        ax.plot(js, fs, 'o-', ms=2.0, lw=0.8, label='$B=%d$' % B)
        ax.axhline((B - 1) / 2.0, color='0.65', ls=':', lw=0.6)
    ax.set_xlabel('digit index $j$', labelpad=1)
    ax.set_ylabel('$F_j$', labelpad=1)
    ax.set_ylim(-0.15, 8.60)         # free band 5.2..8.6
    ax.set_title('(a) $F_j\\to(B-1)/2$', pad=3)
    ax.legend(frameon=False, ncol=1, loc='upper left')

    ax = fig.add_subplot(gs[0, 1])
    for B in (3, 5, 7, 10):
        js, ex = [], []
        for j in range(2, 10):
            if B ** (j - 1) > 2e6:
                break
            js.append(j)
            ex.append(abs(float(Fj(B, j)) - (B - 1) / 2.0))
        if js:
            ax.semilogy(js, ex, 'o-', ms=2.0, lw=0.8, label='$B=%d$' % B)
            jj = np.array(js, dtype=float)
            ax.semilogy(jj, ex[0] * B ** (-(jj - js[0]) / 2.0), '--', lw=0.6,
                        color='0.65')
    ax.set_xlabel('$j$', labelpad=1)
    ax.set_ylabel('$|F_j-(B-1)/2|$', labelpad=1)
    ax.set_title('(b) rate $B^{-j/2}$ (dashed)', pad=3)
    ax.legend(frameon=False, ncol=1)

    ax = fig.add_subplot(gs[1, 0])
    for B, col in ((3, C1), (7, C3), (10, C2)):
        sig = K.Sig(B)
        rs, mus = [], []
        r = 6
        while r <= 30:
            X = int(math.ceil(B ** (r / 2.0)))
            if X > 1500000:
                break
            c, m, s, _ = K.counts(B, r, sig)
            rs.append(r)
            mus.append(sum(n * v for n, v in c.items()) / X)
            r += 1
        rr = np.array(rs, dtype=float)
        ax.plot(rr, mus, 'o', ms=2.4, color=col, label='$B=%d$' % B)
        ax.plot(rr, (B - 1) / 2.0 * rr + DELTA[B], '-', lw=0.9, color=col,
                alpha=0.75)
    ax.set_ylim(0, 108)              # free band 57..108
    ax.set_xlabel('$r$', labelpad=1)
    ax.set_ylabel('$\\mu_r^{\\rm disc}$', labelpad=1)
    ax.set_title('(c) $\\mu_r^{\\rm disc}$ (dots) vs $\\frac{B-1}{2}r+\\Delta_B$ (line)',
                 pad=3)
    ax.legend(frameon=False, ncol=1, loc='upper left')

    ax = fig.add_subplot(gs[1, 1])
    Bs = [2, 3, 5, 7, 10, 16]
    ax.semilogx(Bs, [C_TRUE[b] for b in Bs], 'o-', ms=3.0, lw=0.9, color=C1,
                label='$C_B$ (continuous)')
    ax.semilogx(Bs, [DELTA[b] for b in Bs], 's-', ms=3.0, lw=0.9, color=C2,
                label='$\\Delta_B$ (discrete)')
    for b in (2, 16):
        ax.annotate('%.2f' % DELTA[b], xy=(b, DELTA[b]), xytext=(0, 6),
                    textcoords='offset points', ha='center', va='bottom',
                    fontsize=6.0, color=C2, bbox=WB, zorder=5)
    ax.set_xlim(1.55, 24)
    ax.set_ylim(-10.8, 1.05)         # free band at the lower left
    ax.set_xticks(Bs)
    ax.set_xticklabels([str(b) for b in Bs])
    ax.minorticks_off()
    ax.set_xlabel('base $B$', labelpad=1)
    ax.set_ylabel('the two constants', labelpad=1)
    ax.set_title('(d) $C_B$ and $\\Delta_B$ (Prop. 5.3)', pad=3)
    ax.legend(frameon=False, ncol=1, loc='lower left')
    return K.save(fig, 'Figure 4 (moments)', path)


# ==================================================================== F6
def fig6(path=None):
    path = path or _p('F6')
    fig = plt.figure(figsize=(6.9, 3.9))
    gs = fig.add_gridspec(2, 2, hspace=0.50, wspace=0.30)

    ax = fig.add_subplot(gs[0, 0])
    for B, col in ((2, C1), (3, C_ORANGE), (5, C3), (10, C2)):
        sig = K.Sig(B)
        rs, mx = [], []
        r = 4
        while r <= 22:
            X = int(math.ceil(B ** (r / 2.0)))
            if X > 1.2e6:
                break
            c, _m, _s, _X = K.counts(B, r, sig)
            rs.append(r)
            mx.append(max(c.values()))
            r += 1
        ax.semilogy(rs, mx, 'o-', ms=2.2, lw=0.8, color=col, label='$B=%d$' % B)
        ax.semilogy(rs, [B ** (x / 2.0) for x in rs], ':', lw=0.7, color=C_GREY)
    ax.set_xlabel('$r$', labelpad=1)
    ax.set_ylabel('$\\max_n N_{B,r}(n)$', labelpad=1)
    ax.set_ylim(0.4, 3.0e10)         # free band 10^7..10^10
    ax.set_title('(a) largest fibre, bounded by $B^{r/2}$', pad=3)
    ax.legend(frameon=False, ncol=1, loc='upper left')

    ax = fig.add_subplot(gs[0, 1])
    for B, col in ((2, C1), (3, C_ORANGE), (5, C3), (7, C2), (10, C_PURPLE)):
        sig = K.Sig(B)
        rs, rate = [], []
        r = 4
        while r <= 22:
            X = int(math.ceil(B ** (r / 2.0)))
            if X > 1.2e6:
                break
            c, _m, _s, _X = K.counts(B, r, sig)
            rs.append(r)
            rate.append(math.log(max(c.values())) / r)
            r += 1
        ax.plot(rs, rate, 'o-', ms=2.2, lw=0.8, color=col, label='$B=%d$' % B)
        ax.axhline(math.log(B) / 2.0, ls=':', lw=0.7, color=C_GREY)
    ax.set_xlabel('$r$', labelpad=1)
    ax.set_ylabel('$\\log(\\max N)/r$', labelpad=1)
    ax.set_ylim(0.08, 2.30)          # free band 1.1..2.3
    ax.set_title('(b) rate tends to $(\\log B)/2$', pad=3)
    ax.legend(frameon=False, ncol=1, loc='upper left')

    ax = fig.add_subplot(gs[1, 0])
    B = 10
    sig = K.Sig(B)
    for r, st in ((6, '-'), (8, '--'), (10, '-.')):
        c, mu, sd, X = K.counts(B, r, sig)
        ns = sorted(c)
        ax.plot([(n - mu) / sd for n in ns], [c[n] * sd / X for n in ns], st,
                lw=1.0, label='$r=%d$' % r)
    c, mu, sd, X = K.counts(B, 10, sig)
    ns = sorted(c)
    ax.plot([(n - mu) / sd for n in ns],
            [K.lam_b(n, B) * math.exp(-((n - mu) / sd) ** 2 / 2.0)
             / math.sqrt(2 * math.pi) for n in ns],
            ':', lw=1.1, color='0.45', label='main term')
    ax.set_xlabel('$(n-\\mu_r)/\\Sigma_r$', labelpad=1)
    ax.set_ylabel('scaled count', labelpad=1)
    ax.set_ylim(-0.06, 3.10)         # free band 1.5..3.1
    ax.set_title('(c) collapsed profiles and $\\lambda_B\\varphi$', pad=3)
    ax.legend(frameon=False, ncol=1, loc='upper left')

    ax = fig.add_subplot(gs[1, 1])
    for (B, c), (x, y, u, v), st, col in (
            ((10, 1), (6, 19, 19, 6), 'o-', C1),
            ((2, -1), (1, 1, 3, 2), 'o--', C_ORANGE),
            ((3, 1), (1, 2, 2, 1), 'o-.', C3),
            ((5, 4), (1, 3, 9, 4), 'o:', C2)):
        o = K.pell_orbit(B, c, x, y, u, v, 5 if B == 10 else 4)
        ax.loglog([p[0] ** 2 for p in o], [p[1] ** 2 for p in o], st, ms=2.4,
                  lw=0.8, color=col, label='$B=%d,\\ c=%d$' % (B, c))
    ax.loglog([1, 1e14], [11, 1e15], ':', lw=0.8, color=C_GREY)
    ax.set_xlim(3.2, 5.0e14)         # limits chosen so the corner tick labels
    ax.set_ylim(26.0, 1.2e17)        # (10^-1 and 10^-2) do not appear at all
    ax.set_xlabel('$S=x^2$', labelpad=1)
    ax.set_ylabel('$T=y^2$', labelpad=1)
    ax.set_title('(d) Pell orbits; dotted $T=10S+1$', pad=3)
    ax.legend(frameon=False, ncol=1, loc='upper left')
    return K.save(fig, 'Figure 6 (growth)', path)



def fig0(path=None):
    path = path or _p('F0')
    from matplotlib.patches import FancyBboxPatch
    # Save current rcParams to restore later
    old_rc = plt.rcParams.copy()
    plt.rcParams.update({
        'font.family': 'serif',
        'font.serif': ['Times New Roman', 'STIXGeneral', 'DejaVu Serif'],
        'mathtext.fontset': 'stix',
        'figure.dpi': 300,
        'savefig.bbox': 'tight',
        'savefig.pad_inches': 0.08,
    })

    fig = plt.figure(figsize=(9.2, 6.4), facecolor='white')
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.axis('off')

    def rbox(x, y, w, h, fc, ec, lw=1.1, rad=1.4, z=2, alpha=1.0, ls='-'):
        p = FancyBboxPatch((x, y), w, h,
                           boxstyle=f'round,pad=0,rounding_size={rad}',
                           facecolor=fc, edgecolor=ec, linewidth=lw,
                           linestyle=ls, alpha=alpha, zorder=z)
        ax.add_patch(p)
        return p

    def pill(x, y, w, h, fc, text, tc='white', fs=7.8, z=4, rad=1.0):
        p = FancyBboxPatch((x, y), w, h,
                           boxstyle=f'round,pad=0,rounding_size={rad}',
                           facecolor=fc, edgecolor='none', zorder=z)
        ax.add_patch(p)
        ax.text(x + w / 2.0, y + h / 2.0, text, ha='center', va='center',
                color=tc, fontsize=fs, fontweight='bold', zorder=z + 1)

    def badge(cx, cy, r_x, r_y, fc, text, tc='white', fs=7.5, z=6):
        p = FancyBboxPatch((cx - r_x, cy - r_y), 2 * r_x, 2 * r_y,
                           boxstyle=f'round,pad=0,rounding_size={min(r_x, r_y)}',
                           facecolor=fc, edgecolor='white', linewidth=0.9, zorder=z)
        ax.add_patch(p)
        ax.text(cx, cy, text, ha='center', va='center', color=tc,
                fontsize=fs, fontweight='bold', zorder=z + 1)

    def arrow(x1, y1, x2, y2, col='#475569', lw=1.3, label=None, lx=0, ly=1.6,
              fs=6.8, lcol='#1E293B', bg='white', rad=0.0):
        conn = f'arc3,rad={rad}' if rad != 0 else 'arc3,rad=0'
        ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                    arrowprops=dict(arrowstyle='-|>,head_length=0.55,head_width=0.32',
                                    color=col, lw=lw, shrinkA=1.5, shrinkB=1.5,
                                    connectionstyle=conn),
                    zorder=5)
        if label:
            mx, my = (x1 + x2) / 2.0 + lx, (y1 + y2) / 2.0 + ly
            ax.text(mx, my, label, ha='center', va='center', fontsize=fs,
                    color=lcol, fontweight='bold', zorder=6,
                    bbox=dict(boxstyle='round,pad=0.22', facecolor=bg,
                              edgecolor='none', alpha=0.92))

    # =========================================================================
    # TOP BANNER: OVERALL TITLE
    # =========================================================================
    rbox(1.0, 94.2, 98.0, 4.8, fc='#0F172A', ec='#1E293B', lw=1.2, rad=1.2, z=2)
    ax.text(50.0, 96.6,
            'THE XL THEOREM: ALGEBRAIC CORE, GEOMETRIC IMAGE AND ANALYTIC CONSEQUENCES',
            ha='center', va='center', color='#F8FAFC', fontsize=9.0,
            fontweight='bold', zorder=4)

    # =========================================================================
    # PANEL (a): THE CONSTRUCTION & DIGIT SEMANTICS (Top-Left, Cobalt Blue)
    # =========================================================================
    rbox(1.0, 56.5, 47.2, 36.2, fc='#F8FAFC', ec='#93C5FD', lw=1.2, rad=1.6, z=1)
    pill(1.0, 89.1, 47.2, 3.6, fc='#1D4ED8',
         text='(a) Split-Concatenate-Transform Construction (§1-§2)', fs=8.0, rad=1.2)

    # Step 1: Input
    rbox(2.8, 80.2, 19.2, 7.0, fc='#EFF6FF', ec='#3B82F6', lw=1.1, rad=1.0, z=3)
    badge(4.4, 86.0, 1.3, 1.3, '#1D4ED8', '1', fs=6.8)
    ax.text(12.4, 84.8, 'Input Parameters', ha='center', va='center',
            fontsize=7.2, fontweight='bold', color='#1E3A8A', zorder=4)
    ax.text(12.4, 81.9, r'$B \geq 2,\ c \in \mathbb{Z},\ n = a + b$',
            ha='center', va='center', fontsize=7.5, color='#0F172A', zorder=4)

    # Arrow 1 -> 2
    arrow(22.2, 83.7, 27.6, 83.7, col='#2563EB', label=r'$\sigma_n(a)$', ly=1.8, fs=6.8,
          lcol='#1D4ED8', bg='#F8FAFC')

    # Step 2: Splitting & Segments
    rbox(27.8, 80.2, 19.0, 7.0, fc='#EFF6FF', ec='#3B82F6', lw=1.1, rad=1.0, z=3)
    badge(29.4, 86.0, 1.3, 1.3, '#1D4ED8', '2', fs=6.8)
    ax.text(37.3, 84.8, 'Splitting & Digit Regime', ha='center', va='center',
            fontsize=7.1, fontweight='bold', color='#1E3A8A', zorder=4)
    ax.text(37.3, 81.9, r'$n \mapsto (a, n-a),\ 0 \leq a \leq n \leq B-1$',
            ha='center', va='center', fontsize=6.9, color='#0F172A', zorder=4)

    # Arrow 2 -> 3
    arrow(37.3, 80.0, 26.5, 75.2, col='#2563EB', label=r'$\kappa_B(a,b)=Ba+b$',
          lx=5.2, ly=0.3, fs=6.6, lcol='#1D4ED8', bg='#F8FAFC')

    # Step 3: Concatenation S_B
    rbox(4.5, 67.8, 40.5, 7.0, fc='#DBEAFE', ec='#2563EB', lw=1.3, rad=1.0, z=3)
    badge(6.2, 73.6, 1.3, 1.3, '#1E40AF', '3', fs=6.8)
    ax.text(24.8, 72.6, 'Single-Slot Concatenation Progression (Difference $B-1$)',
            ha='center', va='center', fontsize=7.2, fontweight='bold', color='#1E3A8A', zorder=4)
    ax.text(24.8, 69.6, r'$S_B(a, n) = Ba + (n - a) = n + (B - 1)a \equiv n \ (\mathrm{mod}\ B-1)$',
            ha='center', va='center', fontsize=7.6, color='#0F172A', zorder=4)

    # Arrow 3 -> 4
    arrow(24.8, 67.6, 24.8, 64.6, col='#0284C7', label=r'$\tau_{B,c}(x)=Bx+c$',
          lx=8.2, ly=0.0, fs=6.7, lcol='#0369A1', bg='#F8FAFC')

    # Step 4: Post-Transform T_{B,c}
    rbox(4.5, 57.6, 40.5, 6.8, fc='#E0F2FE', ec='#0284C7', lw=1.3, rad=1.0, z=3)
    badge(6.2, 63.2, 1.3, 1.3, '#0369A1', '4', fs=6.8)
    ax.text(24.8, 62.2, 'Post-Transform Progression (Difference $B(B-1)$, Ratio $B$)',
            ha='center', va='center', fontsize=7.2, fontweight='bold', color='#0C4A6E', zorder=4)
    ax.text(24.8, 59.3,
            r'$T_{B,c}(a, n) = B S_B(a, n) + c = Bn + B(B - 1)a + c \equiv n + c \ (\mathrm{mod}\ B-1)$',
            ha='center', va='center', fontsize=7.3, color='#0F172A', zorder=4)

    # =========================================================================
    # PANEL (b): THE RANK-ONE KERNEL & GEOMETRIC LINE (Top-Right, Royal Purple)
    # =========================================================================
    rbox(50.5, 56.5, 48.5, 36.2, fc='#FAF5FF', ec='#C4B5FD', lw=1.2, rad=1.6, z=1)
    pill(50.5, 89.1, 48.5, 3.6, fc='#6D28D9',
         text='(b) Theorem 2.1 (XL Theorem): Rank-One Kernel & Collinear Image', fs=8.0, rad=1.2)

    # Coupling arrow from Panel (a) to Panel (b)
    arrow(45.2, 66.0, 52.0, 66.0, col='#7C3AED', lw=1.6, label=r'$\Phi(a,n)$',
          lx=0.4, ly=2.3, fs=7.0, lcol='#6D28D9', bg='white')

    # Left sub-card in (b): Linear Operator & 2x2 Matrix
    rbox(52.0, 68.5, 25.5, 19.0, fc='#F3E8FF', ec='#8B5CF6', lw=1.2, rad=1.1, z=3)
    ax.text(64.75, 85.3, 'Rank-One Linear Kernel', ha='center', va='center',
            fontsize=7.5, fontweight='bold', color='#4C1D95', zorder=4)
    ax.text(64.75, 82.3, r'$\Phi(a, n) = M_B (a, n)^{\mathsf{T}} + (0, c)^{\mathsf{T}}$',
            ha='center', va='center', fontsize=7.2, color='#1E1B4B', zorder=4)

    # Draw a true visual 2x2 matrix box with brackets
    rbox(57.2, 73.6, 15.1, 6.8, fc='white', ec='#A78BFA', lw=0.9, rad=0.6, z=4)
    ax.text(55.4, 77.0, r'$M_B =$', ha='right', va='center', fontsize=7.6,
            color='#1E1B4B', zorder=5)
    # Left & right matrix brackets
    ax.plot([57.8, 57.1, 57.1, 57.8], [79.8, 79.8, 74.2, 74.2], color='#4C1D95', lw=1.2, zorder=5)
    ax.plot([71.7, 72.4, 72.4, 71.7], [79.8, 79.8, 74.2, 74.2], color='#4C1D95', lw=1.2, zorder=5)
    ax.text(61.5, 78.3, r'$B-1$', ha='center', va='center', fontsize=7.4, color='#0F172A', zorder=5)
    ax.text(68.8, 78.3, r'$1$', ha='center', va='center', fontsize=7.4, color='#0F172A', zorder=5)
    ax.text(61.5, 75.4, r'$B(B-1)$', ha='center', va='center', fontsize=7.4, color='#0F172A', zorder=5)
    ax.text(68.8, 75.4, r'$B$', ha='center', va='center', fontsize=7.4, color='#0F172A', zorder=5)

    ax.text(64.75, 70.6, r'$\det M_B = 0,\ \ \mathrm{rank}\ M_B = 1$',
            ha='center', va='center', fontsize=7.4, fontweight='bold', color='#be185d', zorder=4)

    # Right sub-card in (b): Mini geometric plot of the image line T = B S + c
    rbox(78.8, 68.5, 18.8, 19.0, fc='white', ec='#A78BFA', lw=1.1, rad=1.1, z=3)
    ax.text(88.2, 85.4, 'Image Line $T = BS + c$', ha='center', va='center',
            fontsize=7.2, fontweight='bold', color='#4C1D95', zorder=4)
    # Axes inside mini plot
    ox, oy = 80.8, 71.2
    ax.annotate('', xy=(96.5, oy), xytext=(ox - 0.5, oy),
                arrowprops=dict(arrowstyle='->', color='#64748B', lw=0.8), zorder=4)
    ax.annotate('', xy=(ox, 83.8), xytext=(ox, oy - 0.5),
                arrowprops=dict(arrowstyle='->', color='#64748B', lw=0.8), zorder=4)
    ax.text(96.2, oy - 1.4, '$S$', ha='center', va='center', fontsize=6.5, color='#475569', zorder=5)
    ax.text(ox - 1.1, 83.2, '$T$', ha='center', va='center', fontsize=6.5, color='#475569', zorder=5)
    # Line T = B S + c
    lx = np.linspace(80.2, 95.2, 50)
    ly = 70.6 + (lx - 80.2) * 0.78
    ax.plot(lx, ly, '-', color='#7C3AED', lw=1.3, zorder=4)
    # Negative segment (amber), Positive segment (emerald), Super segment (crimson)
    pts_x = [81.2, 83.4, 85.6, 87.8, 90.0, 92.2, 94.4]
    pts_y = [70.6 + (px - 80.2) * 0.78 for px in pts_x]
    ax.scatter(pts_x[:1], pts_y[:1], s=18, color='#F59E0B', edgecolor='#78350F', lw=0.5, zorder=6)
    ax.scatter(pts_x[1:5], pts_y[1:5], s=22, color='#10B981', edgecolor='#064E3B', lw=0.6, zorder=6)
    ax.scatter(pts_x[5:], pts_y[5:], s=22, marker='X', color='#EF4444', edgecolor='#7F1D1D', lw=0.5, zorder=6)
    # Mini legend labels
    ax.text(87.2, 79.8, 'Pos. ($D_B$)', color='#059669', fontsize=5.8, fontweight='bold', zorder=6)
    ax.text(92.8, 76.2, 'Super', color='#DC2626', fontsize=5.8, fontweight='bold', zorder=6)
    ax.text(83.6, 71.9, 'Neg.', color='#D97706', fontsize=5.8, fontweight='bold', zorder=6)

    # Bottom bar in (b): Forced Collinearity & Modular Graph
    rbox(52.0, 57.6, 45.6, 9.4, fc='#FDF2F8', ec='#DB2777', lw=1.2, rad=1.0, z=3)
    ax.text(74.8, 64.6,
            r'Forced Collinearity: $\mathrm{Im}(\Phi) = \{(u,\ Bu + c) : u \in \mathbb{Z}\}$',
            ha='center', va='center', fontsize=7.4, fontweight='bold', color='#9D174D', zorder=4)
    ax.text(74.8, 61.6,
            r'Ratio Invariant: $\Delta T / \Delta S = B(B-1)/(B-1) = B$  (common parametrization $\Longleftrightarrow \delta = B-1$)',
            ha='center', va='center', fontsize=6.4, color='#1F2937', zorder=4)
    ax.text(74.8, 59.0,
            r'Modular Image (for every $m \geq 2$): $\Phi(\mathbb{Z}^2)\ \mathrm{mod}\ m = \{(u, Bu+c) : u \in \mathbb{Z}/m\mathbb{Z}\}$ of cardinality $m$',
            ha='center', va='center', fontsize=6.4, color='#831843', zorder=4)

    # =========================================================================
    # PANEL (c): FIVE FAMILIES OF CONSEQUENCES (Middle Band, 5 Vibrant Cards)
    # =========================================================================
    # Branching connector from top panels to the 5 consequence cards
    ax.plot([50.0, 50.0], [56.5, 53.8], color='#475569', lw=1.4, zorder=3)
    ax.plot([10.4, 89.6], [53.8, 53.8], color='#475569', lw=1.4, zorder=3)
    card_centers = [10.4, 30.2, 50.0, 69.8, 89.6]
    for cx in card_centers:
        arrow(cx, 53.8, cx, 51.0, col='#475569', lw=1.2)
    pill(37.0, 52.5, 26.0, 2.6, fc='#334155',
         text='(c) Five Structural & Analytic Consequences', fs=7.3, rad=0.8, z=5)

    cards = [
        # Card 1: Emerald Green
        dict(cx=10.4, head=r'I. Digit Set $D_B$ (§3)',
             hc='#059669', fc='#ECFDF5', ec='#34D399', tc='#065F46',
             l1=r'$D_B = \bigcup_{a=0}^{B-1}[Ba, (a+1)(B-1)]$',
             l2=r'Cardinality $|D_B| = \frac{B(B+1)}{2}$',
             l3=r'Constant-time $O(1)$ indicator $\rho_B$',
             l4=r'Unique ambiguity $\{0, B(B-1)\}$'),
        # Card 2: Cyan / Teal
        dict(cx=30.2, head=r'II. Staircase $\Gamma_B$ (§4.1-4.2)',
             hc='#0891B2', fc='#ECFEFF', ec='#22D3EE', tc='#155E75',
             l1=r'$\Gamma_B(a, n-a) = n + (B^k - 1)a$',
             l2=r'Piecewise affine, slopes $B^k - 1$',
             l3=r'Downward jump at $k \to k-1$',
             l4=r'Iterated tower $d_k = (B-1)B^{k-1}$'),
        # Card 3: Indigo
        dict(cx=50.0, head=r'III. $r$-Slot Slices (§4.3-4.4)',
             hc='#4F46E5', fc='#EEF2FF', ec='#818CF8', tc='#3730A3',
             l1=r'Transfer lattice $= (B-1)\mathbb{Z}$',
             l2=r'Inclusion-exclusion count $C_{B,r}(n)$',
             l3=r'Symmetry $C_{B,r}(r(B-1)-n)$',
             l4=r'Greedy digit slice extrema $V_B$'),
        # Card 4: Amber / Orange
        dict(cx=69.8, head=r'IV. Squares in Slices (§5)',
             hc='#D97706', fc='#FFFBEB', ec='#FBBF24', tc='#92400E',
             l1=r'$\lambda_B(n)=0 \Longrightarrow N_{B,r}(n)=0$',
             l2=r'Density weight $(2\sqrt{v})^{-1}$ on $v<B^r$',
             l3=r'Moment constants $C_B \neq \Delta_B$',
             l4=r'Rate $\frac{1}{r}\log\max N \to \frac{\log B}{2}$'),
        # Card 5: Rose / Crimson
        dict(cx=89.6, head='V. Diophantine & Codes (§6-7)',
             hc='#E11D48', fc='#FFF1F2', ec='#FB7185', tc='#9F1239',
             l1=r'Pell norm core $y^2 - Bx^2 = c$',
             l2=r'Unit orbits $\varepsilon_B = u + v\sqrt{B}$',
             l3=r'Inverse law $\varepsilon = \delta(\delta+1)$',
             l4=r'Checksum blind spots mod $B\pm 1$'),
    ]

    cw, ch, cy0 = 18.6, 26.2, 24.6
    for c in cards:
        x0 = c['cx'] - cw / 2.0
        rbox(x0, cy0, cw, ch, fc=c['fc'], ec=c['ec'], lw=1.2, rad=1.2, z=2)
        pill(x0, cy0 + ch - 3.6, cw, 3.6, fc=c['hc'], text=c['head'], fs=6.9, rad=1.0, z=4)
        ax.text(c['cx'], cy0 + 18.5, c['l1'], ha='center', va='center',
                fontsize=6.5, fontweight='bold', color='#0F172A', zorder=4)
        ax.plot([x0 + 1.4, x0 + cw - 1.4], [cy0 + 15.6, cy0 + 15.6],
                color=c['ec'], lw=0.7, ls='--', zorder=3)
        ax.text(c['cx'], cy0 + 12.6, c['l2'], ha='center', va='center',
                fontsize=6.3, color=c['tc'], zorder=4)
        ax.text(c['cx'], cy0 + 7.8, c['l3'], ha='center', va='center',
                fontsize=6.3, color='#1E293B', zorder=4)
        ax.text(c['cx'], cy0 + 3.0, c['l4'], ha='center', va='center',
                fontsize=6.3, color=c['tc'], fontweight='bold', zorder=4)

    # =========================================================================
    # PANEL (d): THE RESEARCH FRONTIER (Bottom Band, 3-Stage Flow)
    # =========================================================================
    arrow(69.8, 24.6, 69.8, 20.6, col='#D97706', lw=1.4)
    rbox(1.0, 1.2, 98.0, 19.2, fc='#F8FAFC', ec='#64748B', lw=1.2, rad=1.5, z=1)
    pill(1.0, 16.9, 98.0, 3.5, fc='#0F172A',
         text='(d) The Research Frontier: Why the Exponential-Sum Route Fails and Where the Problem Moves (§5.3 & §9)',
         fs=7.6, rad=1.1, z=4)

    # Left box: Sup-Norm Failure (Closed Route)
    rbox(2.6, 2.4, 29.5, 13.3, fc='#FEF2F2', ec='#EF4444', lw=1.2, rad=1.0, z=3)
    pill(3.8, 12.3, 27.1, 2.6, fc='#DC2626',
         text='[Closed Route] Sup-Norm Hypothesis (Thm 5.7)', fs=6.5, rad=0.7, z=4)
    ax.text(17.35, 9.6, r'Scale mismatch: spike width $\Sigma_r^{-1} \asymp r^{-1/2} \gg X^{-c}$',
            ha='center', va='center', fontsize=6.4, color='#7F1D1D', zorder=4)
    ax.text(17.35, 6.6, r'$M(X^{-c})/X \to 1$, plus rational resonances $j/(B-1)$',
            ha='center', va='center', fontsize=6.4, color='#0F172A', zorder=4)
    ax.text(17.35, 3.8, r'No exponent $\eta > 0$ gives $|F_r(\theta)| \leq X^{1-\eta}$',
            ha='center', va='center', fontsize=6.4, fontweight='bold', color='#B91C1C', zorder=4)

    arrow(32.3, 9.0, 35.5, 9.0, col='#DC2626', lw=1.4, label='redirect', ly=2.0, fs=6.3,
          lcol='#991B1B', bg='#F8FAFC')

    # Middle box: Carry Identity Bridge
    rbox(35.7, 2.4, 28.6, 13.3, fc='#EFF6FF', ec='#3B82F6', lw=1.2, rad=1.0, z=3)
    pill(36.9, 12.3, 26.2, 2.6, fc='#2563EB',
         text='[Exact Bridge] The Carry Identity (Thm 5.9)', fs=6.5, rad=0.7, z=4)
    ax.text(50.0, 9.4, r'$\sigma_B(x^2) = \sigma_B(x)^2 - (B - 1)\kappa(x)$',
            ha='center', va='center', fontsize=7.5, fontweight='bold', color='#1E3A8A', zorder=4)
    ax.text(50.0, 6.4, r'$\sigma_B(x)$ is elementary; all digit coupling lives in $\kappa(x)$',
            ha='center', va='center', fontsize=6.3, color='#0F172A', zorder=4)
    ax.text(50.0, 3.8, r'Verified for $B \in \{2,3,5,7,10,16\},\ x < 3000$ (0 errors)',
            ha='center', va='center', fontsize=6.2, color='#1D4ED8', zorder=4)

    arrow(64.5, 9.0, 67.7, 9.0, col='#059669', lw=1.4, label='isolates', ly=2.0, fs=6.3,
          lcol='#065F46', bg='#F8FAFC')

    # Right box: Single Open Frontier
    rbox(67.9, 2.4, 29.5, 13.3, fc='#ECFDF5', ec='#10B981', lw=1.2, rad=1.0, z=3)
    pill(69.1, 12.3, 27.1, 2.6, fc='#059669',
         text='[Open Frontier] Moments & Pair Correlation', fs=6.5, rad=0.7, z=4)
    ax.text(82.65, 9.6, r'1. Closed form for discrete shift $\Delta_B \neq C_B$ (Prop. 5.3)',
            ha='center', va='center', fontsize=6.4, fontweight='bold', color='#065F46', zorder=4)
    ax.text(82.65, 6.6, r'2. Distribution & cumulants of carry count $\kappa(x)$',
            ha='center', va='center', fontsize=6.4, color='#0F172A', zorder=4)
    ax.text(82.65, 3.8, r'3. Pair-correlation law $\sum N_{B,r}(n)^2$ (Conj. 5.10)',
            ha='center', va='center', fontsize=6.4, fontweight='bold', color='#047857', zorder=4)

    fig.savefig(path, dpi=300)
    plt.close(fig)
    plt.rcParams.update(old_rc)
    print(f'saved {path} ({os.path.getsize(path)} bytes)')


OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                   '..', 'data', 'figures')
os.makedirs(OUT, exist_ok=True)


def _p(name):
    return os.path.join(OUT, name + '.png')


if __name__ == '__main__':
    for fn, name in ((fig0, 'F0'), (fig1, 'F1'), (fig2, 'F2'), (fig3, 'F3'),
                     (fig3v, 'F3v'), (fig5, 'F5'), (fig6, 'F6')):
        p = fn()
        if p:
            PROBLEMS[name] = p
    print()
    print('=' * 60)
    if PROBLEMS:
        print('OVERLAPS FOUND IN:', list(PROBLEMS))
    else:
        print('all six figures clean')
    print('=' * 60)