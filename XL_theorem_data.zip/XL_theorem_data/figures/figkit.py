# -*- coding: utf-8 -*-
"""Shared data generators and an automatic overlap checker for the figures.

The checker reports
  * text-on-text overlaps (labels, titles, tick labels, legend entries),
  * text-on-data overlaps (any plotted vertex or marker falling inside a
    text bounding box),
  * legend frames covering data.
Every figure is refused unless the report is empty.
"""
import math
from collections import defaultdict
from functools import lru_cache

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt  # noqa: E402

plt.rcParams.update({'font.size': 7.6, 'axes.linewidth': 0.7,
                     'xtick.major.width': 0.7, 'ytick.major.width': 0.7,
                     'figure.dpi': 300, 'savefig.bbox': 'tight',
                     'axes.titlesize': 7.8, 'legend.fontsize': 6.4})
C1, C2, C3 = '#3b6ea5', '#c1272d', '#4d8b57'
WB = dict(facecolor='white', edgecolor='none', pad=1.2)


# ------------------------------------------------------------------ data
class Sig:
    """Base-B digit sum, tabulated for speed."""

    def __init__(self, B, k=4):
        self.B = B
        self.Bk = B ** k
        self.t = [0] * (self.Bk + 1)
        for v in range(1, self.Bk + 1):
            self.t[v] = self.t[v // B] + (v % B)

    def __call__(self, v):
        t, Bk = self.t, self.Bk
        s = 0
        while v:
            s += t[v % Bk]
            v //= Bk
        return s


def lam_b(n, B):
    m = B - 1
    return sum(1 for t in range(m) if (t * t) % m == (n % m))


def counts(B, r, sig):
    """N_{B,r}(n) for every n, by brute force over x < ceil(B^{r/2})."""
    X = int(math.ceil(B ** (r / 2.0)))
    c = defaultdict(int)
    s1 = s2 = 0
    for x in range(X):
        v = sig(x * x)
        c[v] += 1
        s1 += v
        s2 += v * v
    mu = s1 / X
    return c, mu, math.sqrt(s2 / X - mu * mu), X


def slice_count(B, r, n):
    @lru_cache(maxsize=None)
    def f(k, s):
        if k == 0:
            return 1 if s == 0 else 0
        return sum(f(k - 1, s - d) for d in range(0, min(B - 1, s) + 1))
    return f(r, n)


def slice_values(B, r, n):
    """All V_B of the digit vectors with digit sum n."""
    out = []

    def rec(i, left, val):
        if i == r:
            if left == 0:
                out.append(val)
            return
        for d in range(0, min(B - 1, left) + 1):
            rec(i + 1, left - d, val + d * (B ** (r - 1 - i)))
    rec(0, n, 0)
    return out


def sig_val(a, B, n):
    """The staircase Gamma_B(a, n-a) of Theorem 4.1."""
    b = n - a
    k = 1 if b == 0 else int(math.floor(math.log(b, B))) + 1
    return a * B ** k + b


def pell_orbit(B, c, x, y, u, v, steps):
    out = []
    for _ in range(steps):
        out.append((x, y))
        x, y = u * x + v * y, v * B * x + u * y
    return out


def D_set(B):
    return sorted({n + (B - 1) * a
                   for n in range(B) for a in range(B) if a <= n <= B - 1})


def carries(x, B):
    d, y = [], x
    while y:
        y, q = divmod(y, B)
        d.append(q)
    if not d:
        d = [0]
    c = [0] * (2 * len(d) + 2)
    for i in range(len(d)):
        for j in range(len(d)):
            c[i + j] += d[i] * d[j]
    k = 0
    for j in range(len(c) - 1):
        while c[j] >= B:
            c[j] -= B
            c[j + 1] += 1
            k += 1
    return k


# ------------------------------------------------------- overlap checker
def _text_boxes(fig):
    """Only texts that are actually drawn and are NOT masked by an opaque
    bounding box (a white box deliberately hides what is underneath it)."""
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    boxes = []
    seen = set()
    for axid, ax in enumerate(fig.axes):
        cand = list(ax.texts)
        cand += [ax.title, ax.xaxis.label, ax.yaxis.label]
        for t in ax.get_xticklabels() + ax.get_yticklabels():
            if t.get_text().strip() and t.get_visible():
                cand.append(t)
        leg = ax.get_legend()
        if leg is not None:
            cand += list(leg.get_texts())
        for t in cand:
            if not t.get_text().strip() or not t.get_visible():
                continue
            bp = t.get_bbox_patch()
            if bp is not None:
                fc = bp.get_facecolor()
                if len(fc) == 4 and fc[3] > 0.5:      # opaque white box
                    continue
            try:
                bb = t.get_window_extent(r)
            except Exception:
                continue
            if bb.width <= 0 or bb.height <= 0:
                continue
            key = (axid, t.get_text(), round(bb.x0), round(bb.y0))
            if key in seen:
                continue
            seen.add(key)
            boxes.append((axid, t.get_text(), bb))
    return boxes


def _data_points(fig):
    """Return (axes index, x, y, radius) in display coordinates."""
    pts = []
    for axid, ax in enumerate(fig.axes):
        for ln in ax.get_lines():
            xy = ln.get_xydata()
            if len(xy) == 0:
                continue
            disp = ax.transData.transform(xy)
            ms = ln.get_markersize() if ln.get_marker() not in ('', 'None', None) else 0
            for x, y in disp:
                if math.isfinite(x) and math.isfinite(y):
                    pts.append((axid, x, y, ms / 2.0))
        for coll in ax.collections:
            try:
                off = coll.get_offsets()
            except Exception:
                continue
            if off is None or len(off) == 0:
                continue
            disp = ax.transData.transform(off)
            for x, y in disp:
                if math.isfinite(x) and math.isfinite(y):
                    pts.append((axid, x, y, 1.5))
    return pts


def check_overlaps(fig, name, tol=0.6, verbose=True):
    """Return a list of problems; empty means the figure is clean.

    Both tests are restricted to a single axes, so that tick labels of
    neighbouring panels are never compared with one another.
    """
    boxes = _text_boxes(fig)
    pts = _data_points(fig)
    bad = []
    for i in range(len(boxes)):
        axid, ti, bi = boxes[i]
        for j in range(i + 1, len(boxes)):
            axid2, tj, bj = boxes[j]
            if axid != axid2:
                continue
            dx = min(bi.x1, bj.x1) - max(bi.x0, bj.x0)
            dy = min(bi.y1, bj.y1) - max(bi.y0, bj.y0)
            if dx > tol and dy > tol:
                bad.append(('text/text', ti[:30], tj[:30], round(dx, 1), round(dy, 1)))
    for axid, ti, bi in boxes:
        for axid2, x, y, rad in pts:
            if axid2 != axid:
                continue
            if (bi.x0 - rad) <= x <= (bi.x1 + rad) and (bi.y0 - rad) <= y <= (bi.y1 + rad):
                bad.append(('text/data', ti[:30], 'point at (%.0f,%.0f)' % (x, y), 0, 0))
                break
    if verbose:
        if bad:
            print('  [%s] %d PROBLEM(S)' % (name, len(bad)))
            for b in bad[:12]:
                print('      ', b)
        else:
            print('  [%s] clean -- no text/text or text/data overlap' % name)
    return bad


def save(fig, name, path):
    bad = check_overlaps(fig, name)
    fig.savefig(path)
    plt.close(fig)
    return bad