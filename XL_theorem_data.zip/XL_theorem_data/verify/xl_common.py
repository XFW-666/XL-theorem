"""Shared primitives for the verification programs.

Every quantity used in the paper is rebuilt here from its definition.
"""
import math
from collections import defaultdict
from functools import lru_cache

import mpmath

mpmath.mp.dps = 200


def digit_sum(v, B):
    """sigma_B(v), the sum of the base-B digits of v."""
    s = 0
    while v:
        v, d = divmod(v, B)
        s += d
    return s


class DigitSum:
    """sigma_B, tabulated on blocks so that large ranges stay cheap."""

    def __init__(self, B, k=4):
        self.B = B
        self.block = B ** k
        self.table = [0] * (self.block + 1)
        for v in range(1, self.block + 1):
            self.table[v] = self.table[v // B] + (v % B)

    def __call__(self, v):
        t, blk, s = self.table, self.block, 0
        while v:
            s += t[v % blk]
            v //= blk
        return s


def lambda_B(n, B):
    """Number of square roots of n modulo B-1."""
    m = B - 1
    return sum(1 for t in range(m) if (t * t) % m == (n % m))


def slice_count(B, r, n):
    """C_{B,r}(n), the number of digit vectors of length r with sum n."""
    @lru_cache(maxsize=None)
    def f(k, s):
        if k == 0:
            return 1 if s == 0 else 0
        return sum(f(k - 1, s - d) for d in range(0, min(B - 1, s) + 1))
    return f(r, n)


def slice_values(B, r, n):
    """All V_B of the digit vectors of length r with digit sum n."""
    out = []

    def rec(i, left, val):
        if i == r:
            if left == 0:
                out.append(val)
            return
        for d in range(0, min(B - 1, left) + 1):
            rec(i + 1, left - d, val + d * (B ** (r - 1 - i)))
    rec(0, n, 0)
    return out


def counts(B, r):
    """N_{B,r}(n) over all n, with the discrete mean and standard deviation.

    The support is x = 0 .. ceil(B^(r/2)) - 1, which is exactly the set of
    integers with x^2 < B^r.
    """
    sig = DigitSum(B)
    X = int(math.ceil(B ** (r / 2.0)))
    cnt = defaultdict(int)
    s1 = s2 = 0
    for x in range(X):
        v = sig(x * x)
        cnt[v] += 1
        s1 += v
        s2 += v * v
    mu = s1 / X
    return cnt, mu, math.sqrt(s2 / X - mu * mu), X


def staircase(a, B, n):
    """Gamma_B(a, n-a), the true string concatenation of Theorem 4.1."""
    b = n - a
    k = 1 if b == 0 else int(math.floor(math.log(b, B))) + 1
    return a * B ** k + b


def pell_orbit(B, c, x, y, u, v, steps):
    """Iterate the fundamental unit u + v sqrt(B) on y + x sqrt(B)."""
    out = []
    for _ in range(steps):
        out.append((x, y))
        x, y = u * x + v * y, v * B * x + u * y
    return out


def digit_realizable(B):
    """D_B as a sorted list, built straight from its definition."""
    return sorted({n + (B - 1) * a
                   for n in range(B) for a in range(B) if a <= n <= B - 1})


def carries(x, B):
    """kappa(x): carries needed to normalise the raw coefficients of x^2."""
    d, y = [], x
    while y:
        y, q = divmod(y, B)
        d.append(q)
    if not d:
        d = [0]
    c = [0] * (2 * len(d) + 2)
    for i in range(len(d)):
        for j in range(len(d)):
            c[i + j] += d[i] * d[j]
    k = 0
    for j in range(len(c) - 1):
        while c[j] >= B:
            c[j] -= B
            c[j + 1] += 1
            k += 1
    return k


def density_sum(B, r, targets):
    """S_{B,r}(n) = sum over v < B^r with sigma_B(v) = n of (2 sqrt v)^-1."""
    d = {n: 0.0 for n in targets}

    def rec(i, left, val, n):
        if i == r:
            if left == 0 and val > 0:
                d[n] += 0.5 / math.sqrt(val)
            return
        for dig in range(0, min(B - 1, left) + 1):
            rec(i + 1, left - dig, val + dig * (B ** (r - 1 - i)), n)
    for n in targets:
        rec(0, n, 0, n)
    return d


class Report:
    """Collects pass/fail lines."""

    def __init__(self, title):
        self.title = title
        self.passed = 0
        self.failed = []

    def check(self, label, ok, detail=''):
        if ok:
            self.passed += 1
        else:
            self.failed.append(label)
        print('  [%s] %-58s %s' % ('ok  ' if ok else 'FAIL', label, detail))

    def close(self):
        print()
        print('%s: %d checks passed, %d failed' % (self.title, self.passed,
                                                   len(self.failed)))
        for f in self.failed:
            print('   FAILED: %s' % f)
        return self.passed, len(self.failed)


# ------------------------------------------------------------------------
# The digit moments F_j and the two constants C_B, Delta_B.
#
# F_j = B^{-j/2} sum_{l<B^{j-1}} H_B(l) with
#   H_B(l) = (B-1) sqrt((l+1)B) - sum_{k=1}^{B-1} sqrt(lB+k).
# The telescoping identity
#   sum_{l<M} H_B(l) = (B-1) sqrt(B) S(M) - S(BM-1) + sqrt(B) S(M-1),
# with S(n) = sum_{v<=n} sqrt(v), makes F_j cost O(1) for any j, so that
# C_B = sum_{j>=1} (F_j - (B-1)/2) can be summed to convergence.
# The identity was cross-checked against direct summation to 2e-14.
# ------------------------------------------------------------------------

def S_sqrt(n, K=12):
    n = int(n)
    if n <= 0:
        return mpmath.mpf(0)
    if n <= 300000:
        return mpmath.fsum(mpmath.sqrt(v) for v in range(1, n + 1))
    x = mpmath.mpf(n)
    out = (mpmath.mpf(2) / 3 * x ** mpmath.mpf('1.5')
           + mpmath.mpf(1) / 2 * mpmath.sqrt(x)
           + mpmath.zeta(mpmath.mpf(-1) / 2))
    for k in range(1, K + 1):
        coef = mpmath.mpf(1)
        for j in range(0, 2 * k - 1):
            coef *= (mpmath.mpf(1) / 2 - j)
        out += (mpmath.zeta(2 * k) / mpmath.factorial(2 * k) * coef
                * x ** (mpmath.mpf(3) / 2 - 2 * k))
    return out


def F_j(B, j):
    """F_j, the expected j-th digit of V = U^2 in the continuous model."""
    M = B ** (j - 1)
    tot = ((B - 1) * mpmath.sqrt(B) * S_sqrt(M) - S_sqrt(B * M - 1)
           + mpmath.sqrt(B) * S_sqrt(M - 1))
    return tot / mpmath.mpf(B) ** (mpmath.mpf(j) / 2)


def mu_continuous(B, r):
    return mpmath.fsum(F_j(B, j) for j in range(1, r + 1))


def C_B(B, tol='1e-40'):
    """C_B = sum_{j>=1} (F_j - (B-1)/2), summed until the terms die out."""
    tot = mpmath.mpf(0)
    j = 1
    while j < 600:
        term = F_j(B, j) - mpmath.mpf(B - 1) / 2
        tot += term
        if abs(term) < mpmath.mpf(tol):
            break
        j += 1
    return float(tot), j


def delta_B(B, rmax=40, cap=4000000):
    """Delta_B, by extrapolating D_r = mu_r^disc - (B-1) r / 2.

    Returns (estimate, [(r, D_r), ...]) over the largest feasible r values.
    The tail is extrapolated with the last observed geometric ratio.
    """
    sig = DigitSum(B)
    rs, D = [], []
    r = 4
    while r <= rmax:
        X = int(math.ceil(B ** (r / 2.0)))
        if X > cap:
            break
        tot = sum(sig(x * x) for x in range(X))
        rs.append(r)
        D.append(tot / X - (B - 1) / 2.0 * r)
        r += 2
    if len(D) < 4:
        return None, list(zip(rs, D))
    inc = [D[i + 1] - D[i] for i in range(len(D) - 1)]
    q = abs(inc[-1]) / max(abs(inc[-2]), 1e-12) if inc[-2] else 0.5
    q = min(max(q, 0.05), 0.9)
    return D[-1] + inc[-1] * q / (1 - q), list(zip(rs, D))
