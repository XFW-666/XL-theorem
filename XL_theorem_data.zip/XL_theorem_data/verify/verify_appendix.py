"""Appendix A: the checksum blind spot and the limits of the construction."""
import sys

from xl_common import DigitSum, Report


def main():
    R = Report('Appendix A')

    # ---- Theorem A.1: detection rates of the two classical moduli
    for B, mod, miss, tr in ((10, 9, 2, '0/90'), (10, 11, 0, '90/90'),
                             (16, 15, 2, '0/240'), (16, 17, 0, '240/240'),
                             (7, 8, 0, '36/42'), (5, 6, 0, '16/20')):
        m = sum(1 for d in range(B) for e in range(B)
                if d != e and (e - d) % mod == 0)
        R.check('Thm A.1  single substitutions missed, B = %d, modulus %d'
                % (B, mod), m == miss, 'computed %d' % m)
        caught = 0
        total = 0
        for d in range(B):
            for e in range(B):
                if d == e:
                    continue
                total += 1
                if ((e - d) * (B - 1)) % mod != 0:
                    caught += 1
        R.check('Thm A.1  adjacent transpositions detected, B = %d, modulus %d'
                % (B, mod), '%d/%d' % (caught, total) == tr,
                'computed %d/%d' % (caught, total))

    # ---- Theorem A.3: n = 3 is admissible in base 3 yet is no digit sum
    B = 3
    sig = DigitSum(B)
    hits = set()
    for x in range(3 ** 7):
        hits.add(sig(x * x))
    R.check('Thm A.3  3 is a quadratic residue mod 2 yet 3 is not a digit sum',
            3 % (B - 1) in {0, 1} and 3 not in hits, 'squares below 3^14 scanned')

    # ---- Theorem A.4: the admissible set is decidable
    bad = 0
    for B, r, n in ((3, 4, 3), (3, 5, 4), (10, 3, 9), (5, 3, 6)):
        found = False
        for a in range(B ** r):
            v = 0
            t = a
            s = 0
            for _ in range(r):
                d = t % B
                s += d
                t //= B
            if s != n:
                continue
            v = a
            q = int(round(v ** 0.5))
            if q * q == v:
                found = True
                break
        # brute force over squares instead
        ok = any(sig(q * q) == n and q * q < B ** r
                 for q in range(int(B ** (r / 2.0)) + 1))
        if ok != found:
            bad += 1
    R.check('Thm A.4  existence of an r-digit square with digit sum n is '
            'decided consistently', bad == 0, 'four (B, r, n) cases')

    return R.close()


if __name__ == '__main__':
    sys.exit(1 if main()[1] else 0)
