"""Write the numerical tables of the paper into ../data/."""
import csv
import math
import os
import sys

import mpmath

from xl_common import (C_B, DigitSum, F_j, counts, delta_B, lambda_B,
                       mu_continuous, density_sum, slice_count)

mpmath.mp.dps = 200
DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')
os.makedirs(DATA, exist_ok=True)


def write(name, header, rows):
    path = os.path.join(DATA, name)
    with open(path, 'w', newline='', encoding='utf-8') as fh:
        wr = csv.writer(fh)
        wr.writerow(header)
        wr.writerows(rows)
    print('  wrote %-28s %d rows' % (name, len(rows)))


BASES = (2, 3, 5, 7, 10, 16)

# ---- the two constants, the convergence ratios, the closed-form error -----
rows = []
ratios = {}
for B in BASES:
    c, jstop = C_B(B)
    d, seq = delta_B(B)
    r = []
    for j in range(2, 6):
        prev = abs(float(F_j(B, j - 1)) - (B - 1) / 2.0)
        cur = abs(float(F_j(B, j)) - (B - 1) / 2.0)
        r.append(cur / prev if prev else float('nan'))
    ratios[B] = r
    rows.append([B, '%.6f' % c, '%.4f' % d, '%.4f' % (d - c),
                 '%.4f' % r[0], '%.4f' % r[1], '%.4f' % r[2], '%.4f' % r[3],
                 '%.4f' % (1 / math.sqrt(B))])
write('C_B_and_Delta_B.csv',
      ['B', 'C_B_continuous', 'Delta_B_discrete', 'Delta_B_minus_C_B',
       'ratio_j2', 'ratio_j3', 'ratio_j4', 'ratio_j5', 'limit_1_over_sqrtB'],
      rows)

rows = []
for B, rs in ((10, (4, 6, 8, 10)), (7, (4, 6, 8, 10)), (3, (6, 8, 10)),
              (5, (6, 8, 10))):
    c, _ = C_B(B)
    for r in rs:
        err = abs(mu_continuous(B, r) - (mpmath.mpf(B - 1) / 2 * r + c))
        rows.append([B, r, '%.6f' % float(err)])
write('closed_form_error.csv', ['B', 'r', 'abs_error'], rows)

# ---- the L1 errors over the band |n - mu| <= 3 sigma ---------------------
rows = []
for B, r in ((10, 6), (5, 9), (3, 13), (2, 20)):
    cnt, mu, sd, X = counts(B, r)
    band = [n for n in cnt if abs(n - mu) <= 3 * sd]
    S = density_sum(B, r, band)
    e1 = sum(abs(cnt[n] - lambda_B(n, B) * S.get(n, 0.0)) for n in band)
    e0 = sum(abs(cnt[n] - slice_count(B, r, n) / B ** (r / 2.0)) for n in band)
    rows.append([B, r, X, len(band), '%.2f' % e1, '%.2f' % e0,
                 '%.4f' % (e1 / e0)])
write('L1_errors.csv',
      ['B', 'r', 'X', 'band_size', 'L1_main_term', 'L1_uniform', 'gain'], rows)

# ---- the exponential bracket --------------------------------------------
rows = []
for B in (2, 3, 5, 7, 10):
    for r in range(4, 13):
        X = int(math.ceil(B ** (r / 2.0)))
        if X > 3000000:
            break
        cnt, mu, sd, _ = counts(B, r)
        mx = max(cnt.values())
        rows.append([B, r, X, mx,
                     '%.4f' % (B ** (r / 2.0) / (r * (B - 1) + 1)),
                     '%.4f' % B ** (r / 2.0),
                     '%.6f' % (math.log(mx) / r),
                     '%.6f' % (math.log(B) / 2)])
write('exponential_bracket.csv',
      ['B', 'r', 'X', 'max_N', 'lower_bound', 'upper_bound', 'rate',
       'limit_logB_over_2'], rows)

# ---- the sup-norm quotients ---------------------------------------------
rows = []
for B, r in ((10, 4), (10, 5), (10, 6)):
    cnt, mu, sd, X = counts(B, r)
    sig = DigitSum(B)
    seq = [sig(x * x) for x in range(X)]
    for label, delta in (('X^{-1/2}', 1.0 / math.sqrt(X)), ('X^{-1}', 1.0 / X)):
        best, bth = 0.0, 0.0
        t = delta
        while t <= 0.5:
            re_ = math.fsum(math.cos(2 * math.pi * t * v) for v in seq)
            im_ = math.fsum(math.sin(2 * math.pi * t * v) for v in seq)
            if math.hypot(re_, im_) > best:
                best, bth = math.hypot(re_, im_), t
            t += 1.0 / 4000.0
        rows.append([B, r, label, '%.6f' % delta, '%.4f' % (best / X),
                     '%.4f' % bth])
write('supnorm_quotients.csv',
      ['B', 'r', 'threshold', 'delta', 'M_over_X', 'theta_of_max'], rows)

print('  tables written to data/')
