"""Theorems 6.1, 6.2, 7.1, 7.2."""
import math
import sys

from xl_common import (DigitSum, digit_realizable, pell_orbit, staircase,
                       Report)


def main():
    R = Report('Sections 6-7')

    # ---- Theorem 6.1: positive-segment double squares
    # x = 0 is the degenerate solution (S = 0, T = c); it is kept in the list
    for B, c, want in ((10, 1, [0, 6]), (10, -1, [1]), (10, 9, [0, 2, 4]),
                       (2, -1, [1]), (3, 1, [0, 1]), (5, 4, [0, 1])):
        D = set(digit_realizable(B))
        sol = []
        for x in range(0, B):
            if x * x in D:
                v = c + B * x * x
                if v >= 0 and int(round(math.sqrt(v))) ** 2 == v:
                    sol.append(x)
        R.check('Thm 6.1  positive-segment double squares, B = %d, c = %d'
                % (B, c), sol == want, 'computed %s' % sol)

    # ---- Theorem 6.2: the orbits and the concatenation rule
    o = pell_orbit(10, 1, 6, 19, 19, 6, 4)
    R.check('Thm 6.2  B=10, c=1 orbit in x', [p[0] for p in o] ==
            [6, 228, 8658, 328776], 'computed %s' % [p[0] for p in o])
    R.check('Thm 6.2  B=10, c=1 orbit in y', [p[1] for p in o] ==
            [19, 721, 27379, 1039681])
    R.check('Thm 6.2  T = 10 S + 1 along the whole orbit',
            all(p[1] ** 2 == 10 * p[0] ** 2 + 1 for p in o))
    R.check('Thm 6.2  B=2, c=-1 orbit', [p[0] for p in
            pell_orbit(2, -1, 1, 1, 3, 2, 5)] == [1, 5, 29, 169, 985])
    R.check('Thm 6.2  B=3, c=1 orbit', [p[0] for p in
            pell_orbit(3, 1, 1, 2, 2, 1, 4)] == [1, 4, 15, 56])
    R.check('Thm 6.2  B=5, c=4 orbit', [p[0] for p in
            pell_orbit(5, 4, 1, 3, 9, 4, 3)] == [1, 21, 377])
    for B, u, v in ((10, 19, 6), (2, 3, 2), (3, 2, 1), (5, 9, 4)):
        R.check('Thm 6.2  fundamental unit of Z[sqrt(%d)]' % B,
                u * u - B * v * v == 1, '%d + %d sqrt(%d)' % (u, v, B))

    # ---- Theorem 7.1: reverse characterization
    bad = 0
    for delta in range(1, 7):
        B = delta + 1
        # n <= B-1 keeps every trailing summand a single digit, so the true
        # concatenation coincides with S_B and the k = 1 window applies
        for n in range(0, min(6, B)):
            for c in (-2, 0, 3):
                S = [staircase(a, B, n) for a in range(0, n + 1)]
                T = [B * v + c for v in S]
                if S != [n + delta * a for a in range(0, n + 1)]:
                    bad += 1
                if any(T[i] - T[i - 1] != B * delta
                       for i in range(1, len(T))):
                    bad += 1
                if any(S[i] - S[i - 1] != delta for i in range(1, len(S))):
                    bad += 1
    R.check('Thm 7.1  the common differences are delta and delta(delta+1)',
            bad == 0, 'delta = 1..6, n = 0..5, c = -2,0,3')

    # ---- Theorem 7.2: finite fields and modular rings
    bad = 0
    for p in (2, 3, 5, 7, 11, 13):
        for B in range(2, 12):
            if B % p == 1:
                for a in range(p):
                    for n in range(p):
                        if (B * a + (n - a)) % p != n % p:
                            bad += 1
            if B % p == 0:
                for a in range(p):
                    for n in range(p):
                        if (B * (B * a + (n - a))) % p != 0:
                            bad += 1
    R.check('Thm 7.2  S_B is constant modulo p when p | B-1, and T is '
            'constant when p | B', bad == 0, 'p <= 13, B <= 11')
    bad = 0
    for m in (2, 3, 5, 6, 9, 12):
        for B in range(2, 9):
            g = math.gcd(m, B - 1)
            orb = {0}
            cur = 0
            while True:
                cur = (cur + B - 1) % m
                if cur in orb:
                    break
                orb.add(cur)
            if len(orb) != m // g:
                bad += 1
    R.check('Thm 7.2  the orbit of n has length m/gcd(m, B-1)', bad == 0,
            'm in {2,3,5,6,9,12}, B = 2..8')

    return R.close()


if __name__ == '__main__':
    sys.exit(1 if main()[1] else 0)
