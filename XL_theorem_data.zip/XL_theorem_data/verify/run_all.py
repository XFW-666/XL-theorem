"""Run every verification program and write the logs.

Usage:  python verify/run_all.py
"""
import io
import os
import subprocess
import sys

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, '..', 'outputs')
os.makedirs(OUT, exist_ok=True)

PROGRAMS = ['verify_sections_2_4.py', 'verify_section_5.py',
            'verify_sections_6_7.py', 'verify_appendix.py',
            'compute_constants.py']
FIG = os.path.join(HERE, '..', 'figures', 'make_figures.py')

total_pass = 0
failed = []
for prog in PROGRAMS:
    print('=' * 72)
    print('running %s' % prog)
    print('=' * 72)
    r = subprocess.run([sys.executable, os.path.join(HERE, prog)],
                       capture_output=True, text=True, encoding='utf-8',
                       errors='replace', cwd=HERE)
    sys.stdout.write(r.stdout)
    if r.stderr.strip():
        sys.stdout.write(r.stderr)
    with io.open(os.path.join(OUT, prog.replace('.py', '.log')), 'w',
                 encoding='utf-8', newline='\n') as fh:
        fh.write(r.stdout)
        fh.write(r.stderr)
    for line in r.stdout.split('\n'):
        if 'checks passed' in line:
            total_pass += int(line.split(':')[1].split('checks')[0].strip())
        if line.strip().startswith('FAILED:'):
            failed.append('%s: %s' % (prog, line.strip()))

print('=' * 72)
print('running %s' % os.path.basename(FIG))
print('=' * 72)
r = subprocess.run([sys.executable, FIG], capture_output=True, text=True, encoding='utf-8',
                       errors='replace')
sys.stdout.write(r.stdout)
if r.stderr.strip():
    sys.stdout.write(r.stderr)
with io.open(os.path.join(OUT, 'make_figures.log'), 'w', encoding='utf-8',
             newline='\n') as fh:
    fh.write(r.stdout)
    fh.write(r.stderr)

print()
print('=' * 72)
print('TOTAL: %d checks passed, %d failed' % (total_pass, len(failed)))
for f in failed:
    print('   ', f)
print('=' * 72)
sys.exit(1 if failed else 0)
