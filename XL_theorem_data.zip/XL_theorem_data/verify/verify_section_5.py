"""Theorems 5.1, 5.2, 5.5, 5.6, 5.7, 5.9, Proposition 5.3, Conjecture 5.10."""
import math
import sys

import mpmath

from xl_common import (DigitSum, carries, counts, density_sum, lambda_B,
                       slice_count, Report)

mpmath.mp.dps = 200


def main():
    R = Report('Section 5')

    # ---- Theorem 5.1: the vanishing criterion
    bad = 0
    for B in (2, 3, 5, 7, 10, 16):
        sig = DigitSum(B)
        X = int(math.ceil(B ** 5.0))
        seen = set()
        for x in range(X):
            seen.add(sig(x * x) % (B - 1))
        for n in range(0, B - 1):
            if lambda_B(n, B) == 0 and n % (B - 1) in seen:
                bad += 1
    R.check('Thm 5.1  a digit sum in a non-residue class never occurs',
            bad == 0, 'B = 2,3,5,7,10,16')
    R.check('Thm 5.1  lambda_10 vanishes exactly on 2,3,5,6,8 mod 9',
            [lambda_B(n, 10) for n in range(9)] == [3, 2, 0, 0, 2, 0, 0, 2, 0])

    # ---- Theorem 5.2 / Proposition 5.3: the two constants
    paper = {2: -0.793618, 3: -1.026326, 5: -1.464413,
             7: -1.882907, 10: -2.490281, 16: -3.664427}
    for B, want in paper.items():
        got, jstop = C_B(B)
        R.check('Thm 5.2  C_B, B = %d' % B, abs(got - want) < 5e-7,
                'computed %.6f after %d terms' % (got, jstop))

    # the two means differ by O(1) and do not agree
    cnt, mu, sd, X = counts(2, 20)
    cont = float(mu_cont(2, 20))
    R.check('Prop 5.3  the discrete and continuous means differ by O(1)',
            abs(mu - cont) > 1.0,
            'discrete %.6f vs continuous %.6f, gap %.3f' % (mu, cont, mu - cont))

    # ---- Theorem 5.5: the exponential bracket
    bad = 0
    rows = []
    for B, r in ((10, 4), (10, 5), (10, 6), (10, 8), (3, 10), (5, 8), (2, 14)):
        c, m, s, X = counts(B, r)
        mx = max(c.values())
        lo = B ** (r / 2.0) / (r * (B - 1) + 1)
        hi = B ** (r / 2.0)
        rows.append((B, r, X, mx, lo, hi))
        if not (lo <= mx <= hi):
            bad += 1
    R.check('Thm 5.5  B^{r/2}/(r(B-1)+1) <= max_n N_{B,r}(n) <= B^{r/2}',
            bad == 0, '%d parameter pairs' % len(rows))

    # ---- Theorem 5.6: the Fourier identity and the remainder bound
    bad = 0
    cases = ((10, 4), (5, 5), (3, 8), (2, 10), (10, 6))
    for B, r in cases:
        cnt, mu, sd, X = counts(B, r)
        sig = DigitSum(B)
        seq = [sig(x * x) for x in range(X)]
        for delta in (0.05, 0.1, 0.2):
            err, bound_ok = fourier_check(seq, X, delta)
            if err > 1e-3 or not bound_ok:
                bad += 1
    R.check('Thm 5.6  N = I_delta + R_delta for every n, and |R_delta| <= M(delta)',
            bad == 0, 'five (B,r) pairs x three thresholds')

    # ---- Theorem 5.7: the sup-norm hypothesis fails
    bad = 0
    for B, r in ((10, 4), (10, 5), (10, 6)):
        cnt, m, s, X = counts(B, r)
        sig = DigitSum(B)
        sg = [sig(x * x) for x in range(X)]
        for delta, lo in ((1.0 / math.sqrt(X), 0.5), (1.0 / X, 0.85)):
            best = 0.0
            t = delta
            while t <= 0.5:
                re_ = math.fsum(math.cos(2 * math.pi * t * v) for v in sg)
                im_ = math.fsum(math.sin(2 * math.pi * t * v) for v in sg)
                best = max(best, math.hypot(re_, im_))
                t += 1.0 / 4000.0
            if best / X < lo:
                bad += 1
    R.check('Thm 5.7  M/X stays near 1 at delta = X^{-1/2} and at delta = X^{-1}',
            bad == 0, 'B = 10, r = 4,5,6')

    # ---- Theorem 5.9: the carry identity
    bad = 0
    for B in (2, 3, 5, 7, 10, 16):
        sig = DigitSum(B)
        for x in range(3000):
            if sig(x * x) != sig(x) ** 2 - (B - 1) * carries(x, B):
                bad += 1
    R.check('Thm 5.9  sigma_B(x^2) = sigma_B(x)^2 - (B-1) kappa(x)',
            bad == 0, 'B = 2,3,5,7,10,16 and x < 3000')

    # ---- Conjecture 5.10: the pair-correlation ratio
    for B, r, lo, hi in ((10, 6, 1.0, 1.005), (16, 5, 0.99, 1.0),
                         (10, 8, 0.99, 1.0)):
        cnt, m, s, X = counts(B, r)
        lhs = sum(v * v for v in cnt.values())
        rhs = X * X * sum(lambda_B(n, B) ** 2
                          * (math.exp(-((n - m) ** 2) / (s * s))
                             / (2 * math.pi * s * s)) for n in cnt)
        R.check('Cons 5.10  pair-correlation ratio, B = %d, r = %d' % (B, r),
                lo <= lhs / rhs <= hi, 'ratio %.4f' % (lhs / rhs))

    return R.close()


def S_sqrt(n, K=12):
    """S(n) = sum_{v<=n} sqrt(v), exact below 3e5, Euler-Maclaurin above."""
    n = int(n)
    if n <= 0:
        return mpmath.mpf(0)
    if n <= 300000:
        return mpmath.fsum(mpmath.sqrt(v) for v in range(1, n + 1))
    x = mpmath.mpf(n)
    out = (mpmath.mpf(2) / 3 * x ** mpmath.mpf('1.5')
           + mpmath.mpf(1) / 2 * mpmath.sqrt(x)
           + mpmath.zeta(mpmath.mpf(-1) / 2))
    for k in range(1, K + 1):
        coef = mpmath.mpf(1)
        for j in range(0, 2 * k - 1):
            coef *= (mpmath.mpf(1) / 2 - j)
        out += (mpmath.zeta(2 * k) / mpmath.factorial(2 * k) * coef
                * x ** (mpmath.mpf(3) / 2 - 2 * k))
    return out


def F_j(B, j):
    M = B ** (j - 1)
    tot = ((B - 1) * mpmath.sqrt(B) * S_sqrt(M) - S_sqrt(B * M - 1)
           + mpmath.sqrt(B) * S_sqrt(M - 1))
    return tot / mpmath.mpf(B) ** (mpmath.mpf(j) / 2)


def mu_cont(B, r):
    return mpmath.fsum(F_j(B, j) for j in range(1, r + 1))


def C_B(B, tol='1e-40'):
    tot = mpmath.mpf(0)
    j = 1
    while j < 600:
        term = F_j(B, j) - mpmath.mpf(B - 1) / 2
        tot += term
        if abs(term) < mpmath.mpf(tol):
            break
        j += 1
    return float(tot), j


def F_theta(seq, theta):
    """F_r(theta) = sum_x exp(2 pi i theta sigma_B(x^2))."""
    return sum(complex(math.cos(2 * math.pi * theta * v),
                       math.sin(2 * math.pi * theta * v)) for v in seq)


def fourier_check(seq, X, delta, nq=3000, ns=2000):
    """Return (max_n |N(n) - I_delta(n) - R_delta(n)|, bound_satisfied).

    The identity is checked for every n, not for a single one, and the bound
    |R_delta| <= M(delta) is checked against the maximum over |theta| >= delta.
    """
    def I_of(n):
        tot = 0j
        for i in range(-nq, nq):
            th = delta * (i + 0.5) / nq
            tot += F_theta(seq, th) * complex(math.cos(-2 * math.pi * th * n),
                                              math.sin(-2 * math.pi * th * n))
        return tot * 2 * delta / (2 * nq)

    def R_of(n):
        tot = 0j
        for i in range(ns):
            th = delta + (0.5 - delta) * (i + 0.5) / ns
            tot += F_theta(seq, th) * complex(math.cos(-2 * math.pi * th * n),
                                              math.sin(-2 * math.pi * th * n))
            tot += F_theta(seq, -th) * complex(math.cos(2 * math.pi * th * n),
                                               math.sin(2 * math.pi * th * n))
        return tot * (0.5 - delta) / ns

    n_max = max(v for v in seq)
    M = max(abs(F_theta(seq, delta + (0.5 - delta) * (i + 0.5) / 400))
            for i in range(400))
    worst = 0.0
    worst_bound = True
    for n in range(0, n_max + 1):
        N = seq.count(n)
        rec = I_of(n) + R_of(n)
        worst = max(worst, abs(rec.real - N))
        if abs(R_of(n)) > M * 1.02:
            worst_bound = False
    return worst, worst_bound


if __name__ == '__main__':
    sys.exit(1 if main()[1] else 0)
