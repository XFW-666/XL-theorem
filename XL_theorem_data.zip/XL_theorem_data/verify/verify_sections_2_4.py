"""Theorems 2.1, 3.1, 3.2, 4.1, 4.2, 4.3, 4.4."""
import math
import sys

from xl_common import (DigitSum, digit_sum, digit_realizable, slice_count,
                       slice_values, staircase, Report)


def main():
    R = Report('Sections 2-4')

    # ---- Theorem 2.1: rank-one kernel and the modular invariants
    bad = 0
    for B in range(2, 13):
        for c in (-3, 0, 1, 5):
            for a in range(-6, 15):
                for n in range(-6, 15):
                    S = B * a + (n - a)
                    T = B * S + c
                    if S != n + (B - 1) * a:
                        bad += 1
                    if T != B * n + B * (B - 1) * a + c:
                        bad += 1
                    if (S - n) % (B - 1) != 0 or (T - c) % B != 0 \
                            or (T - S - c) % (B - 1) != 0:
                        bad += 1
    R.check('Thm 2.1  rank-one identity and the three congruences, B=2..12',
            bad == 0, '%d violations' % bad)

    # ---- Theorem 3.1: structure and cardinality of D_B
    ok = True
    for B in range(2, 13):
        D = digit_realizable(B)
        if len(D) != B * (B + 1) // 2:
            ok = False
        iv = [[B * a, (a + 1) * (B - 1)] for a in range(B)]
        for i in range(len(iv) - 1):
            if iv[i][1] >= iv[i + 1][0]:
                ok = False
        if sorted({v for lo, hi in iv for v in range(lo, hi + 1)}) != D:
            ok = False
    R.check('Thm 3.1  D_B is a disjoint union of B intervals, |D_B| = B(B+1)/2',
            ok, 'B = 2..12')

    # ---- Theorem 3.2: membership test and closed-form indicator
    bad = 0
    for B in range(2, 11):
        D = set(digit_realizable(B))
        for u in range(0, B * (B - 1) + 3):
            r = u % (B - 1)
            if r >= 1:
                pred = (r <= u <= r * B)
            else:
                pred = (u == 0) or (B - 1 <= u <= B * (B - 1))
            if pred != (u in D):
                bad += 1
            rho = max(0, u // B - max(0, -(-(u - B + 1) // (B - 1))) + 1)
            if rho not in (0, 1) or (rho == 1) != (u in D):
                bad += 1
    R.check('Thm 3.2  membership criterion and indicator rho_B, B=2..10',
            bad == 0, '%d violations' % bad)

    # ---- Theorem 4.1: staircase and jumps
    bad = 0
    for B in (2, 7, 10):
        n = 57
        prev = None
        prev_k = None
        for a in range(0, n + 1):
            b = n - a
            k = 1 if b == 0 else int(math.floor(math.log(b, B))) + 1
            g = staircase(a, B, n)
            if prev is not None:
                if k == prev_k:
                    # inside one window Gamma = n + a (B^k - 1), so it rises
                    if g - prev != B ** k - 1:
                        bad += 1
                else:
                    # at a transition the staircase drops
                    if g - prev >= 0:
                        bad += 1
            prev, prev_k = g, k
    R.check('Thm 4.1  within a window the slope is B^k-1, at a transition the '
            'staircase drops', bad == 0, 'B = 2, 7, 10, n = 57')
    R.check('Thm 4.1  jump at the k=2 -> k=1 transition, B=10, n=57',
            staircase(48, 10, 57) - staircase(47, 10, 57) == -4221,
            'computed %d' % (staircase(48, 10, 57) - staircase(47, 10, 57)))

    # ---- Theorem 4.2: iterated tower
    bad = 0
    for B in (2, 5, 10, 16):
        for c in (-2, 0, 3):
            for k in range(1, 9):
                for a in range(0, 6):
                    n = 5
                    S = B * a + (n - a)
                    F = S
                    for _ in range(k - 1):
                        F = B * F + c
                    closed = (B ** (k - 1) * S
                              + c * (B ** (k - 1) - 1) // (B - 1))
                    if F != closed:
                        bad += 1
                    # as a function of a the common difference is (B-1) B^{k-1}
                    S1 = B * (a + 1) + (n - (a + 1))
                    F1 = S1
                    for _ in range(k - 1):
                        F1 = B * F1 + c
                    if F1 - F != (B - 1) * B ** (k - 1):
                        bad += 1
    R.check('Thm 4.2  closed form and geometric tower of differences',
            bad == 0, '%d violations' % bad)

    # ---- Theorem 4.3: transfer differences generate (B-1)Z
    bad = 0
    for B in range(2, 12):
        for r in range(2, 6):
            gens = []
            for i in range(1, r + 1):
                for j in range(1, r + 1):
                    if i == j:
                        continue
                    g = B ** (r - i) - B ** (r - j)
                    gens.append(g)
                    if g % (B - 1) != 0:
                        bad += 1
            gg = 0
            for g in gens:
                gg = math.gcd(gg, abs(g))
            if gg != B - 1:
                bad += 1
    R.check('Thm 4.3  every transfer difference is divisible by B-1 and they '
            'generate exactly (B-1)Z', bad == 0, 'B = 2..11, r = 2..5')

    # ---- Theorem 4.4: slice counts, symmetry, greedy extrema
    bad = 0
    for B in range(2, 8):
        for r in range(1, 6):
            for n in range(0, r * (B - 1) + 1):
                c = slice_count(B, r, n)
                if c != len(slice_values(B, r, n)):
                    bad += 1
                if c != slice_count(B, r, r * (B - 1) - n):
                    bad += 1
                v = slice_values(B, r, n)
                if not v:
                    continue
                gm = 0
                rem = n
                for i in range(r):
                    d = min(B - 1, rem)
                    gm += d * B ** (r - 1 - i)
                    rem -= d
                gn = 0
                rem = n
                for i in range(r):          # least significant digit first
                    d = min(B - 1, rem)
                    gn += d * B ** i
                    rem -= d
                if max(v) != gm:
                    bad += 1
                if min(v) != gn:
                    bad += 1
    R.check('Thm 4.4  inclusion-exclusion count, Dirichlet symmetry and the '
            'greedy extrema', bad == 0, 'B = 2..7, r = 1..5')

    return R.close()


def greedy_max(B, r, n):
    rem, val = n, 0
    for i in range(r):
        d = min(B - 1, rem)
        val += d * B ** (r - 1 - i)
        rem -= d
    return val


def greedy_min(B, r, n):
    rem, val = n, 0
    for i in range(r):              # least significant digit first
        d = min(B - 1, rem)
        val += d * B ** i
        rem -= d
    return val


if __name__ == '__main__':
    sys.exit(1 if main()[1] else 0)
